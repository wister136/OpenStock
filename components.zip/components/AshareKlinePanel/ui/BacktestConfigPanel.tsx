'use client';

import React from 'react';
import { Input } from '@/components/ui/input';
import { cn } from '@/lib/utils';
import type { BacktestConfig } from '../types';

type Props = {
  /** Backtest config (controlled) */
  config: BacktestConfig;
  /** Setter that supports value or updater fn (same style as React.setState) */
  setConfig: (next: BacktestConfig | ((prev: BacktestConfig) => BacktestConfig)) => void;

  /** Optional: for hint text; defaults to 100 */
  lotSize?: number;
};

export default function BacktestConfigPanel({ config, setConfig, lotSize = 100 }: Props) {
  // Use string values for inputs to allow temporary empty input without crashing
  const capitalText = String(config.capital ?? '');
  const feeBpsText = String(config.feeBps ?? '');
  const slippageBpsText = String(config.slippageBps ?? '');
  const orderLotsText = String(config.orderLots ?? '');
  const maxEntriesText = String(config.maxEntries ?? '');

  const allowPyramiding = Boolean(config.allowPyramiding);
  const allowSameDirRepeat = Boolean(config.allowSameDirectionRepeat);

  const updateNumber = (key: keyof BacktestConfig, raw: string) => {
    // Allow empty input (do not update)
    if (raw.trim() === '') return;
    const n = Number(raw);
    if (!Number.isFinite(n)) return;

    setConfig((prev) => ({ ...prev, [key]: n }));
  };

  return (
    <>
      <div className="flex flex-wrap items-center gap-2">
        <div className="text-xs text-gray-400">初始资金</div>
        <Input
          value={capitalText}
          onChange={(e) => updateNumber('capital', e.target.value)}
          className="h-8 w-28 rounded-lg bg-white/5 border-white/10 text-gray-100 text-xs"
        />

        <div className="ml-2 text-xs text-gray-400">手续费(bps)</div>
        <Input
          value={feeBpsText}
          onChange={(e) => updateNumber('feeBps', e.target.value)}
          className="h-8 w-20 rounded-lg bg-white/5 border-white/10 text-gray-100 text-xs"
        />

        <div className="ml-2 text-xs text-gray-400">滑点(bps)</div>
        <Input
          value={slippageBpsText}
          onChange={(e) => updateNumber('slippageBps', e.target.value)}
          className="h-8 w-20 rounded-lg bg-white/5 border-white/10 text-gray-100 text-xs"
        />

        <label className="ml-2 flex items-center gap-2 text-xs text-gray-300 select-none">
          <input
            type="checkbox"
            checked={allowPyramiding}
            onChange={(e) => setConfig((prev) => ({ ...prev, allowPyramiding: e.target.checked }))}
          />
          允许加仓
        </label>

        <div className={cn('ml-2 text-xs text-gray-400', !allowPyramiding && 'opacity-50')}>每次加仓(手)</div>
        <Input
          value={orderLotsText}
          disabled={!allowPyramiding}
          onChange={(e) => updateNumber('orderLots', e.target.value)}
          className="h-8 w-16 rounded-lg bg-white/5 border-white/10 text-gray-100 text-xs disabled:opacity-50"
        />

        <div className={cn('ml-2 text-xs text-gray-400', !allowPyramiding && 'opacity-50')}>最多加仓次数</div>
        <Input
          value={maxEntriesText}
          disabled={!allowPyramiding}
          onChange={(e) => updateNumber('maxEntries', e.target.value)}
          className="h-8 w-16 rounded-lg bg-white/5 border-white/10 text-gray-100 text-xs disabled:opacity-50"
        />

        <label className={cn('ml-2 flex items-center gap-2 text-xs text-gray-300 select-none', !allowPyramiding && 'opacity-50')}>
          <input
            type="checkbox"
            checked={allowSameDirRepeat}
            disabled={!allowPyramiding}
            onChange={(e) => setConfig((prev) => ({ ...prev, allowSameDirectionRepeat: e.target.checked }))}
          />
          同向重复信号
        </label>

        <div className="ml-auto text-xs text-gray-500">信号在收盘生成，下一根开盘成交</div>
      </div>

      <div className="text-[11px] text-gray-500 -mt-1">
        bps=万分之一；成交价=开盘价±滑点；现金流计入手续费；“同向重复信号”仅在“允许加仓”时生效；一手={lotSize}股
      </div>
    </>
  );
}
