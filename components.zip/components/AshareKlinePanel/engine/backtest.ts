// Backtest engine (pure function, next-open execution model)
import type { OHLCVBar } from '@/lib/indicators';
import { lastFinite } from '@/lib/indicators';

import type { StrategyKey, StrategyParams, StrategySignal, BacktestConfig, BacktestResult, BacktestTrade } from '../types';
import { DEFAULT_BACKTEST_CONFIG, DEFAULT_STRATEGY_PARAMS, DEFAULT_INITIAL_CAPITAL, FORCE_CLOSE_AT_END } from '../types';
import { computeStrategySignals } from './strategies';

export function runBacktestNextOpen(
  strategy: StrategyKey,
  bars: OHLCVBar[],
  initialCapital: number,
  cfg: BacktestConfig = DEFAULT_BACKTEST_CONFIG,
  params: StrategyParams = DEFAULT_STRATEGY_PARAMS
): BacktestResult {
  const cap = Number(initialCapital);
  if (!Number.isFinite(cap) || cap <= 0) {
    return {
      ok: false,
      error: '初始资金不合法',
      initialCapital: 0,
      finalEquity: 0,
      netProfit: 0,
      netProfitPct: 0,
      maxDrawdown: 0,
      maxDrawdownPct: 0,
      trades: [],
      winRate: 0,
      profitFactor: null,
      avgTradePct: null,
      buyHoldPct: null,
      grossProfit: 0,
      grossLoss: 0,

      // Backtest model & assumptions（回测口径）
      model: cfg.model,
      lotSize: cfg.lotSize,
      feeBps: cfg.feeBps,
      slippageBps: cfg.slippageBps,
      allowPyramiding: cfg.allowPyramiding,
      allowSameDirectionRepeat: cfg.allowSameDirectionRepeat,
      orderLots: cfg.orderLots,
      maxEntries: cfg.maxEntries,
      forceCloseAtEnd: cfg.forceCloseAtEnd,

      barCount: bars.length,
      validBarCount: 0,
      tradeCount: 0,
      reliabilityLevel: '低',
      reliabilityNotes: ['初始资金不合法'],

      buyHoldFinalEquity: null,
      buyHoldCagrPct: null,

      exposurePct: 0,
      avgWinPct: null,
      avgLossPct: null,
      expectancyPct: null,
      avgBarsHeld: null,
      maxBarsHeld: null,
      maxConsecWins: null,
      maxConsecLosses: null,

      equityCurve: [],
      drawdownPctCurve: [],

      cagrPct: null,
      sharpe: null,
      calmar: null,
      annualVolPct: null,
      sortino: null,
      ulcerIndex: null,
      recoveryFactor: null,

      maxDdDurationDays: null,
      maxDdStart: null,
      maxDdEnd: null,

      sampleStart: null,
      sampleEnd: null,
      sampleDays: null,

      monthlyReturns: [],
    };
  }

  if (!bars.length || strategy === 'none') {
    return {
      ok: false,
      error: '请先选择一个策略',
      initialCapital: cap,
      finalEquity: cap,
      netProfit: 0,
      netProfitPct: 0,
      maxDrawdown: 0,
      maxDrawdownPct: 0,
      trades: [],
      winRate: 0,
      profitFactor: null,
      avgTradePct: null,
      buyHoldPct: null,
      grossProfit: 0,
      grossLoss: 0,

      model: cfg.model,
      lotSize: cfg.lotSize,
      feeBps: cfg.feeBps,
      slippageBps: cfg.slippageBps,
      allowPyramiding: cfg.allowPyramiding,
      allowSameDirectionRepeat: cfg.allowSameDirectionRepeat,
      orderLots: cfg.orderLots,
      maxEntries: cfg.maxEntries,
      forceCloseAtEnd: cfg.forceCloseAtEnd,

      barCount: bars.length,
      validBarCount: bars.length,
      tradeCount: 0,
      reliabilityLevel: '低',
      reliabilityNotes: ['请先选择一个策略'],

      buyHoldFinalEquity: null,
      buyHoldCagrPct: null,

      exposurePct: 0,
      avgWinPct: null,
      avgLossPct: null,
      expectancyPct: null,
      avgBarsHeld: null,
      maxBarsHeld: null,
      maxConsecWins: null,
      maxConsecLosses: null,

      equityCurve: [],
      drawdownPctCurve: [],

      cagrPct: null,
      sharpe: null,
      calmar: null,
      annualVolPct: null,
      sortino: null,
      ulcerIndex: null,
      recoveryFactor: null,

      maxDdDurationDays: null,
      maxDdStart: null,
      maxDdEnd: null,

      sampleStart: null,
      sampleEnd: null,
      sampleDays: null,

      monthlyReturns: [],
    };
  }

  if (bars.length < 5) {
    return {
      ok: false,
      error: '数据不足，无法回测',
      initialCapital: cap,
      finalEquity: cap,
      netProfit: 0,
      netProfitPct: 0,
      maxDrawdown: 0,
      maxDrawdownPct: 0,
      trades: [],
      winRate: 0,
      profitFactor: null,
      avgTradePct: null,
      buyHoldPct: null,
      grossProfit: 0,
      grossLoss: 0,

      model: cfg.model,
      lotSize: cfg.lotSize,
      feeBps: cfg.feeBps,
      slippageBps: cfg.slippageBps,
      allowPyramiding: cfg.allowPyramiding,
      allowSameDirectionRepeat: cfg.allowSameDirectionRepeat,
      orderLots: cfg.orderLots,
      maxEntries: cfg.maxEntries,
      forceCloseAtEnd: cfg.forceCloseAtEnd,

      barCount: bars.length,
      validBarCount: bars.length,
      tradeCount: 0,
      reliabilityLevel: '低',
      reliabilityNotes: ['数据不足，无法回测'],

      buyHoldFinalEquity: null,
      buyHoldCagrPct: null,

      exposurePct: 0,
      avgWinPct: null,
      avgLossPct: null,
      expectancyPct: null,
      avgBarsHeld: null,
      maxBarsHeld: null,
      maxConsecWins: null,
      maxConsecLosses: null,

      equityCurve: [],
      drawdownPctCurve: [],

      cagrPct: null,
      sharpe: null,
      calmar: null,
      annualVolPct: null,
      sortino: null,
      ulcerIndex: null,
      recoveryFactor: null,

      maxDdDurationDays: null,
      maxDdStart: null,
      maxDdEnd: null,

      sampleStart: null,
      sampleEnd: null,
      sampleDays: null,

      monthlyReturns: [],
    };
  }

  const feeRate = Math.max(0, Number(cfg.feeBps) || 0) / 10000;
  const slipRate = Math.max(0, Number(cfg.slippageBps) || 0) / 10000;

  // sample quality
  const barCount = bars.length;
  const validBarCount = bars.reduce((n, b) => {
    const ok = Number.isFinite(b?.t) && Number.isFinite(b?.o) && Number.isFinite(b?.c) && b.o > 0 && b.c > 0;
    return n + (ok ? 1 : 0);
  }, 0);

  // Map: signal at bar[i] close → execute at bar[i+1] open
  const signals = computeStrategySignals(strategy, bars, params);
  const sigByBarIndex = new Map<number, StrategySignal[]>();
  for (const s of signals) {
    const arr = sigByBarIndex.get(s.index) ?? [];
    arr.push(s);
    sigByBarIndex.set(s.index, arr);
  }

  let cash = cap;
  let qty = 0;
  let entryIndex = -1;
  let entryPrice = 0;
  let entryCost = 0;
  let entryTime = 0;
  let entryCount = 0; // number of entry fills (including adds)

  const trades: BacktestTrade[] = [];
  const equityCurve: number[] = [];
  const drawdownPctCurve: number[] = [];
  let holdBars = 0;

  // iterate bars, apply execution at current bar open based on previous bar's signal
  let peakEq = cap;
  for (let idx = 0; idx < bars.length; idx++) {
    if (idx > 0) {
      const prevSig = sigByBarIndex.get(idx - 1);
      if (prevSig && prevSig.length) {
        // if multiple, process SELL first then BUY (safer)
        const ordered = [...prevSig].sort((a, b) => (a.side === 'SELL' ? -1 : 1) - (b.side === 'SELL' ? -1 : 1));
        for (const s of ordered) {
          const px = bars[idx]?.o;
          if (!Number.isFinite(px) || px <= 0) continue;

          if (s.side === 'BUY') {
            // BUY executed at current bar open (next-open model): apply slippage/fee
            const buyPx = px * (1 + slipRate);

            if (qty === 0) {
              // Entry: fixed lots (分批固定手数)，不足则跳过
              const shares = Math.max(1, Math.floor(cfg.orderLots)) * cfg.lotSize;
              const cost = shares * buyPx * (1 + feeRate);
              if (shares <= 0 || !Number.isFinite(cost) || cost > cash) continue;

              qty = shares;
              cash = cash - cost;
              entryIndex = idx;
              entryPrice = buyPx;
              entryCost = cost;
              entryTime = bars[idx]?.t;
              entryCount = 1;
            } else if (cfg.allowPyramiding && cfg.allowSameDirectionRepeat) {
              // Pyramiding (分批加仓): 每次固定手数，最多 cfg.maxEntries 次
              if (entryCount >= Math.max(1, Math.floor(cfg.maxEntries))) continue;

              const addShares = Math.max(1, Math.floor(cfg.orderLots)) * cfg.lotSize;
              const addCost = addShares * buyPx * (1 + feeRate);
              if (addShares <= 0 || !Number.isFinite(addCost) || addCost > cash) continue;

              const newQty = qty + addShares;
              const avgPx = (entryPrice * qty + buyPx * addShares) / newQty;
              entryPrice = Number.isFinite(avgPx) ? avgPx : entryPrice;

              entryCost = entryCost + addCost;
              qty = newQty;
              cash = cash - addCost;
              entryCount += 1;
              // entryIndex / entryTime keep the first entry
            }
            } else if (s.side === 'SELL' && qty > 0) {
            const exitIndex = idx;
            const sellPx = px * (1 - slipRate);
            const exitTime = bars[idx]?.t;

            const proceeds = qty * sellPx * (1 - feeRate);
            const pnl = proceeds - entryCost;
            const pnlPct = entryCost > 0 ? (proceeds / entryCost - 1) * 100 : 0;

            trades.push({
              entryIndex,
              exitIndex,
              entryTime,
              exitTime,
              entryPrice,
              exitPrice: sellPx,
              pnl,
              pnlPct,
              barsHeld: Math.max(0, exitIndex - entryIndex),
              open: false,
              entryFills: entryCount,
              lots: qty / cfg.lotSize,
              shares: qty,
              avgCost: entryCost > 0 && qty > 0 ? entryCost / qty : entryPrice,
            });

            cash = cash + proceeds;
            qty = 0;
            entryIndex = -1;
            entryPrice = 0;
            entryCost = 0;
            entryTime = 0;
            entryCount = 0;
          }
        }
      }
    }

    if (qty > 0) holdBars += 1;

    const closePx = bars[idx]?.c;
    const equity = cash + (qty > 0 && Number.isFinite(closePx) ? qty * closePx : 0);
    const e = Number.isFinite(equity) ? equity : cash;
    equityCurve.push(e);

    if (e > peakEq) peakEq = e;
    const ddPct = peakEq > 0 ? ((peakEq - e) / peakEq) * 100 : 0;
    drawdownPctCurve.push(Number.isFinite(ddPct) ? ddPct : 0);
  }

  // End-of-sample handling:
  // - Equity curve is mark-to-market on each bar close.
  // - For the trade list, we optionally "force-close" the last open position at the last close,
  //   so that PnL is visible and summary metrics are consistent.
  if (cfg.forceCloseAtEnd && qty > 0) {
    const last = bars[bars.length - 1];
    const exitPrice = last?.c;
    const exitTime = last?.t;
    if (Number.isFinite(exitPrice) && exitPrice > 0) {
      // NOTE: this close uses LAST CLOSE (not next-open). Costs are still applied (currently 0).
      const sellPx = exitPrice; // keep clean for reporting
      const proceeds = qty * sellPx * (1 - feeRate);
      const pnl = proceeds - entryCost;
      const pnlPct = entryCost > 0 ? (proceeds / entryCost - 1) * 100 : 0;

      trades.push({
        entryIndex,
        exitIndex: bars.length - 1,
        entryTime,
        exitTime,
        entryPrice,
        exitPrice: sellPx,
        pnl,
        pnlPct,
        barsHeld: Math.max(0, bars.length - 1 - entryIndex),
        open: true,
        entryFills: entryCount,
        lots: qty / cfg.lotSize,
        shares: qty,
        avgCost: entryCost > 0 && qty > 0 ? entryCost / qty : entryPrice,
      });

      cash = cash + proceeds;
      qty = 0;
      entryIndex = -1;
      entryPrice = 0;
      entryCost = 0;
      entryTime = 0;
    }
  }

  const finalEquity = cash;

  // Max drawdown
  let peak = equityCurve.length ? equityCurve[0] : cap;
  let maxDd = 0;
  for (const v of equityCurve) {
    if (v > peak) peak = v;
    const dd = peak - v;
    if (dd > maxDd) maxDd = dd;
  }
  const maxDdPct = peak > 0 ? (maxDd / peak) * 100 : 0;

  // Profit factor, win rate, avg trade
  let grossProfit = 0;
  let grossLoss = 0;
  let wins = 0;
  let losses = 0;
  let sumTradePct = 0;
  for (const tr of trades) {
    if (tr.pnl >= 0) {
      grossProfit += tr.pnl;
      if (!tr.open) wins += 1;
    } else {
      grossLoss += Math.abs(tr.pnl);
      if (!tr.open) losses += 1;
    }
    sumTradePct += tr.pnlPct;
  }
  const closedCount = wins + losses;
  const winRate = closedCount > 0 ? (wins / closedCount) * 100 : 0;
  const profitFactor = grossLoss > 0 ? grossProfit / grossLoss : grossProfit > 0 ? Number.POSITIVE_INFINITY : null;
  const avgTradePct = trades.length ? sumTradePct / trades.length : null;

  // Buy & Hold baseline (first open → last close)
  const firstOpen = bars[0]?.o;
  const lastClose = bars[bars.length - 1]?.c;
  const lotSize = (cfg?.lotSize ?? 100);
  const exposurePct = barCount > 0 ? (holdBars / barCount) * 100 : 0;

  // Baseline: buy&hold with the same sizing (all-in by lot) and same cost settings (currently both = 0)
  let buyHoldFinalEquity: number | null = null;
  let buyHoldPct: number | null = null;
  let buyHoldCagrPct: number | null = null;
  if (Number.isFinite(firstOpen) && firstOpen > 0 && Number.isFinite(lastClose) && lastClose > 0) {
    const bhShares = Math.floor(cap / (firstOpen * (1 + feeRate)) / lotSize) * lotSize;
    const bhCost = bhShares * firstOpen * (1 + feeRate);
    const bhCash = cap - bhCost;
    buyHoldFinalEquity = bhCash + bhShares * lastClose * (1 - feeRate);
    buyHoldPct = cap > 0 ? (buyHoldFinalEquity / cap - 1) * 100 : null;

    const bhFirstTs = bars[0]?.t;
    const bhLastTs = bars[bars.length - 1]?.t;
    if (Number.isFinite(bhFirstTs) && Number.isFinite(bhLastTs)) {
      const years = (bhLastTs - bhFirstTs) / (365.25 * 24 * 3600);
      if (years > 0) buyHoldCagrPct = (Math.pow(buyHoldFinalEquity / cap, 1 / years) - 1) * 100;
    }
  }


  // Extra stats (TradingView-like, simple & stable)
  const closedTrades = trades.filter((t) => !t.open);
  const winsArr = closedTrades.filter((t) => t.pnlPct >= 0);
  const lossesArr = closedTrades.filter((t) => t.pnlPct < 0);
  const avgWinPct = winsArr.length ? winsArr.reduce((a, b) => a + b.pnlPct, 0) / winsArr.length : null;
  const avgLossPct = lossesArr.length ? lossesArr.reduce((a, b) => a + b.pnlPct, 0) / lossesArr.length : null;
  const expectancyPct = closedTrades.length ? closedTrades.reduce((a, b) => a + b.pnlPct, 0) / closedTrades.length : null;
  const avgBarsHeld = closedTrades.length ? closedTrades.reduce((a, b) => a + b.barsHeld, 0) / closedTrades.length : null;
  const maxBarsHeld = closedTrades.length ? Math.max(...closedTrades.map((t) => t.barsHeld)) : null;

  let maxConsecWins: number | null = null;
  let maxConsecLosses: number | null = null;
  if (closedTrades.length) {
    let cw = 0;
    let cl = 0;
    let mw = 0;
    let ml = 0;
    for (const tr of closedTrades) {
      if (tr.pnlPct >= 0) {
        cw += 1;
        cl = 0;
      } else {
        cl += 1;
        cw = 0;
      }
      if (cw > mw) mw = cw;
      if (cl > ml) ml = cl;
    }
    maxConsecWins = mw;
    maxConsecLosses = ml;
  }

  const netProfit = finalEquity - cap;
  const netProfitPct = cap > 0 ? (finalEquity / cap - 1) * 100 : 0;

  // --- Report extras (daily/monthly stats) ---
  let cagrPct: number | null = null;
  let sharpe: number | null = null;
  let calmar: number | null = null;
  let annualVolPct: number | null = null;
  let sortino: number | null = null;
  let recoveryFactor: number | null = null;
  let ulcerIndex: number | null = null;
  let maxDdDurationDays: number | null = null;
  let maxDdStart: string | null = null;
  let maxDdEnd: string | null = null;
  let sampleStart: string | null = null;
  let sampleEnd: string | null = null;
  let sampleDays: number | null = null;
  const monthlyReturns: { month: string; retPct: number }[] = [];

  try {
    const firstTs = bars[0]?.t;
    const lastTs = bars[bars.length - 1]?.t;
    if (Number.isFinite(firstTs) && Number.isFinite(lastTs)) {
      const years = (lastTs - firstTs) / (365.25 * 24 * 3600);
      if (years > 0) {
        cagrPct = (Math.pow(finalEquity / cap, 1 / years) - 1) * 100;
      }
    }

    // build daily equity (use last equity of the day)
    const dayKeys: string[] = [];
    const dayEquity: number[] = [];
    const seen = new Set<string>();
    let lastKey: string | null = null;
    for (let k = 0; k < bars.length; k++) {
      const ts = bars[k]?.t;
      if (!Number.isFinite(ts)) continue;
      const d = new Date(ts * 1000);
      const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
      if (lastKey != key) {
        lastKey = key;
        if (!seen.has(key)) {
          seen.add(key);
          dayKeys.push(key);
          dayEquity.push(equityCurve[k]);
        }
      } else {
        // same day: overwrite last
        dayEquity[dayEquity.length - 1] = equityCurve[k];
      }
    }
    // sharpe (daily)
    const dailyR: number[] = [];
    for (let d = 1; d < dayEquity.length; d++) {
      const a = dayEquity[d - 1];
      const b = dayEquity[d];
      if (a > 0 && Number.isFinite(a) && Number.isFinite(b)) dailyR.push(b / a - 1);
    }
    const dailyMean = dailyR.length ? dailyR.reduce((s, x) => s + x, 0) / dailyR.length : 0;
    const dailyStd = dailyR.length >= 5
      ? Math.sqrt(dailyR.reduce((s, x) => s + (x - dailyMean) ** 2, 0) / (dailyR.length - 1))
      : 0;
    if (dailyStd > 0) sharpe = (dailyMean / dailyStd) * Math.sqrt(252);

    // calmar
    if (cagrPct != null && maxDdPct > 0) calmar = (cagrPct / 100) / (maxDdPct / 100);

    // ---- Enhanced credibility metrics (based on daily equity) ----
    // Annualized volatility (daily), Sortino ratio, drawdown duration, and recovery factor
    annualVolPct = dailyStd > 0 ? (dailyStd * Math.sqrt(252) * 100) : 0;

    const downside = dailyR.filter((r) => r < 0);
    const downsideMean = downside.length ? downside.reduce((s, v) => s + v, 0) / downside.length : 0;
    const downsideStd = downside.length > 1
      ? Math.sqrt(downside.reduce((s, v) => s + Math.pow(v - downsideMean, 2), 0) / (downside.length - 1))
      : 0;
    sortino = downsideStd > 0 ? (dailyMean / downsideStd) * Math.sqrt(252) : (dailyMean > 0 ? Infinity : 0);

    // Max drawdown duration in trading days (peak -> recovery) using daily equity
    let peakEq = dayEquity[0] ?? 0;
    let peakIdx = 0;
    let inDd = false;
    let ddStartIdx = 0;
    let maxDdDur = 0;
    let maxDdStartIdx = 0;
    let maxDdEndIdx = 0;
    for (let i = 1; i < dayEquity.length; i++) {
      const eq = dayEquity[i];
      if (eq >= peakEq) {
        if (inDd) {
          const dur = i - ddStartIdx;
          if (dur > maxDdDur) {
            maxDdDur = dur;
            maxDdStartIdx = ddStartIdx;
            maxDdEndIdx = i;
          }
          inDd = false;
        }
        peakEq = eq;
        peakIdx = i;
      } else {
        if (!inDd) {
          inDd = true;
          ddStartIdx = peakIdx;
        }
        const dur = i - ddStartIdx;
        if (dur > maxDdDur) {
          maxDdDur = dur;
          maxDdStartIdx = ddStartIdx;
          maxDdEndIdx = i;
        }
      }
    }

    maxDdDurationDays = maxDdDur;
    maxDdStart = dayKeys[maxDdStartIdx] ?? '';
    maxDdEnd = dayKeys[maxDdEndIdx] ?? '';

    recoveryFactor = maxDd > 0 ? netProfit / maxDd : Infinity;

    // Ulcer index (based on drawdown percentage curve)
    ulcerIndex = drawdownPctCurve.length
      ? Math.sqrt(drawdownPctCurve.reduce((s, v) => s + v * v, 0) / drawdownPctCurve.length)
      : 0;

    sampleStart = dayKeys[0] ?? '';
    sampleEnd = dayKeys[dayKeys.length - 1] ?? '';
    sampleDays = dayKeys.length;

    // monthly returns from daily equity
    const monthFirst: Record<string, number> = {};
    const monthLast: Record<string, number> = {};
    for (let d = 0; d < dayKeys.length; d++) {
      const key = dayKeys[d];
      const m = key.slice(0, 7);
      if (!(m in monthFirst)) monthFirst[m] = dayEquity[d];
      monthLast[m] = dayEquity[d];
    }
    for (const m of Object.keys(monthLast).sort()) {
      const f = monthFirst[m];
      const l = monthLast[m];
      if (f > 0 && Number.isFinite(f) && Number.isFinite(l)) monthlyReturns.push({ month: m, retPct: (l / f - 1) * 100 });
    }
  } catch (e) {
    // ignore report errors
  }


  // ---- Reliability / credibility hints ----
  const reliabilityNotes: string[] = [];
  const tradeCount = trades.length;

  if (barCount < 200) reliabilityNotes.push(`有效K线较少（${barCount}），统计不稳定`);
  if (validBarCount < barCount) reliabilityNotes.push(`存在无效K线（有效 ${validBarCount}/${barCount}），已按可用数据计算`);
  if (sampleDays != null && sampleDays < 60) reliabilityNotes.push(`覆盖交易日较少（${sampleDays} 天），不代表长期表现`);
  if (tradeCount === 0) reliabilityNotes.push('本样本内没有产生交易，无法评估策略');
  if (tradeCount > 0 && tradeCount < 20) reliabilityNotes.push(`交易次数偏少（${tradeCount} 笔），胜率/因子波动较大`);
  if (FORCE_CLOSE_AT_END) reliabilityNotes.push('最后一笔未平仓按最后收盘价虚拟平仓，仅用于统计展示');

  const lowFlags = [
    barCount < 120,
    sampleDays != null && sampleDays < 30,
    tradeCount > 0 && tradeCount < 5,
    tradeCount === 0,
  ].filter(Boolean).length;

  const reliabilityLevel: '高' | '中' | '低' = lowFlags > 0 ? '低' : reliabilityNotes.length ? '中' : '高';

  return {
    ok: true,
    initialCapital: cap,
    finalEquity,
    netProfit,
    netProfitPct,
    maxDrawdown: maxDd,
    maxDrawdownPct: maxDdPct,
    trades,
    winRate,
    profitFactor,
    avgTradePct,
    buyHoldPct,
    grossProfit,
    grossLoss,
    lotSize,
    model: cfg.model,
    feeBps: cfg.feeBps,
    slippageBps: cfg.slippageBps,
    allowPyramiding: cfg.allowPyramiding,
    allowSameDirectionRepeat: cfg.allowSameDirectionRepeat,
    orderLots: cfg.orderLots,
    maxEntries: cfg.maxEntries,
    forceCloseAtEnd: cfg.forceCloseAtEnd,
    barCount,
    validBarCount,
    tradeCount: trades.length,
    reliabilityLevel,
    reliabilityNotes,
    buyHoldFinalEquity,
    buyHoldCagrPct,
    exposurePct,
    avgWinPct,
    avgLossPct,
    expectancyPct,
    avgBarsHeld,
    maxBarsHeld,
    maxConsecWins,
    maxConsecLosses,
    equityCurve,
    drawdownPctCurve,
    cagrPct,
    sharpe,
    calmar,
    annualVolPct,
    sortino,
    recoveryFactor,
    ulcerIndex,
    maxDdDurationDays,
    maxDdStart,
    maxDdEnd,
    sampleStart,
    sampleEnd,
    sampleDays,
    monthlyReturns,
  };
}
